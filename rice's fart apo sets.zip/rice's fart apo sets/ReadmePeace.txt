Peter's Equalizer APO Configuration Extension (Peace)

An equalizer and effects interface for Equalizer APO by Peter Verbeek

Peace - http://sourceforge.net/projects/peace-equalizer-apo-extension
Equalizer APO - http://sourceforge.net/projects/equalizerapo

Installation:
Run PeaceSetup.exe to install. Or move a downloaded executable Peace.exe to 'Program files\EqualizerAPO\config' and run it.

When you start Peace for the first time, you may get a popup question "Overwrite config.txt?". Saying 'Yes' will activate Peace.
